namespace color {
    /**
     * The original palette buffer for the project
     * 
     * This **must** be defined first in this file because others palettes
     * may be defined relative to this palette
     */
    //% fixedInstance whenUsed block="original"
    export const originalPalette = bufferToPalette(hex`__palette`);

    //% fixedInstance whenUsed block="adafruit"
    export const Adafruit = bufferToPalette(hex`
        000000
        17ABFF
        DF2929
        C600FF
        FF007D
        00FF72
        e5FF00
        0034FF
        FFFFFF
        00EFFF
        FF0000
        7400DB
        636363
        FF7a00
        2D9F00
        000000
    `);

    //% fixedInstance whenUsed block="matte"
    export const Player = bufferToPalette(hex`
        000000
        65C8D0
        36C8D0 
        85C8D0 
        A5C8D0 
        4D4D4D 
        E6E6E6 
        000000
        000000
        000000
        000000
        000000
        000000
        000000
        000000
        000000
    `);

    //% fixedInstance whenUsed block="gray scale"
    export const Enemy1 = bufferToPalette(hex`
        000000
        C58938
        D29246
        FFC379
        FFCF85
        FFDA91
        FDDAA4
        878AA3
        AB000D
        B1000E
        BF0010
        C52E2B
        EEBB2A
        FBCD3B
        FBD53B
        000000
    `);

    // https://lospec.com/palette-list/poke14
    //% fixedInstance whenUsed block="poke"
    export const Enemy2 = bufferToPalette(hex`
        000000
        3C3C3C
        464646
        505050
        5A5A5A
        646464
        6E6E6E
        ED1C24
        AD7268
        D18176
        E18C89
        AB000D
        B1000E
        BF0010
        BF0010
        C52E2B
    `);

    // https://lospec.com/palette-list/warioware-diy
    //% fixedInstance whenUsed block="DIY"
    export const Enemy3 = bufferToPalette(hex`
        000000
        729DD3
        76A6D9
        6CADFF
        78B1FF
        85BCFF
        91C5FF
        208F4A
        EEA700
        F4AF00
        FFB700
        662D91
        72429B
        8150B1
        9F68D5
        000000
    `);

    // https://lospec.com/palette-list/still-life
    //% fixedInstance whenUsed block="still life"
    export const Enemy4 = bufferToPalette(hex`
        000000
        8B000D
        99000D
        AB000D
        B70717
        C50F21
        CB132C
        000000
        282828
        3C3C3C
        5A5A5A
        646464
        787878
        828282
        000000
        000000
    `);

    // https://lospec.com/palette-list/steam-lords, missing 0xa0b9ba
    //% fixedInstance whenUsed block="steam punk"
    export const Boss = bufferToPalette(hex`
        000000
        282828
        3C3C3C
        505050
        646464
        828282
        D7C78B
        A2976B
        C1272D
        ED1C24
        F15A24
        FFFFFF
        FBB03B
        FBC13B
        FBCD3B
        000000
    `)

    // https://lospec.com/palette-list/sweetie-16, missing 0x73eff7
    //% fixedInstance whenUsed block="sweet"
    export const Sweet = bufferToPalette(hex`
        000000
        1a1c2c
        5d275d
        b13e53
        ef7d57
        ffcd75
        a7f070
        38b764
        257179
        29366f
        3b5dc9
        41a6f6
        f4f4f4
        94b0c2
        566c86
        333c57
    `);

    // https://lospec.com/palette-list/na16, missing 0x70377f
    //% fixedInstance whenUsed block="adventure"
    export const Adventure = bufferToPalette(hex`
        000000
        8c8fae
        584563
        3e2137
        9a6348
        d79b7d
        f5edba
        c0c741
        647d34
        e4943a
        9d303b
        d26471
        7ec4c1
        34859d
        17434b
        1f0e1c
    `);

    //% fixedInstance whenUsed block="arcade"
    export const Arcade = bufferToPalette(hex`
        000000
        FFFFFF
        FF2121
        FF93C4
        FF8135
        FFF609
        249CA3
        78DC52
        003FAD
        87F2FF
        8E2EC4
        A4839F
        5C406c
        E5CDC4
        91463d
        000000
    `);

    //% fixedInstance whenUsed block="black"
    export const Black = bufferToPalette(hex`
        000000
        000000
        000000
        000000
        000000
        000000
        000000
        000000
        000000
        000000
        000000
        000000
        000000
        000000
        000000
        000000
    `);

    //% fixedInstance whenUsed block="white"
    export const White = bufferToPalette(hex`
        FFFFFF
        FFFFFF
        FFFFFF
        FFFFFF
        FFFFFF
        FFFFFF
        FFFFFF
        FFFFFF
        FFFFFF
        FFFFFF
        FFFFFF
        FFFFFF
        FFFFFF
        FFFFFF
        FFFFFF
        FFFFFF
    `);
} 
